option one
You can import my project (unziP) on android studio , after installing the flutter sdk and dart sdk you can run it there.
Flutter SDK installed – Check by running:flutter doctor
Step-by-step:
Open Android Studio

Go to Tools > Device Manager

Create and launch an Android Virtual Device (AVD)

Once emulator is running, go back to your project folder in terminal:
flutter run

option two

you can create apk in cmd and run it in any emulator software.
note: things you need to do before creating apk in cmd: downloading the flutter sdk  and adding its bin directory in environmental variables and make sure your windows developer mode is on.

how to create apk in cmd
 
first command:  cd file directory from inside the workoutfitness folder
cd path\to\your\project


then :
flutter pub get
flutter build apk --release
 